#!/bin/bash
# Basic setup script for Ubuntu VM

echo "Updating system..."
sudo apt update && sudo apt upgrade -y

echo "Installing common packages..."
sudo apt install -y curl wget git vim net-tools build-essential

echo "Setup complete."
